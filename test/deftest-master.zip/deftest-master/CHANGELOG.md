## DefTest 2.3.0 [britzl released 2018-06-08]
NEW: Mock GUI now supports get and set node scale

## DefTest 2.2.1 [britzl released 2018-06-06]
FIX: deftest.util.check.equal didn't convert args to strings when formatting the error message

## DefTest 2.2.0 [britzl released 2018-06-06]
NEW: assert_same() and assert_unique()  
CHANGE: assert_equal() accepts more than two values

## DefTest 2.1.1 [britzl released 2018-04-29]
FIX: Node picking of child nodes didn't work in the mock gui

## DefTest 2.1.0 [britzl released 2018-04-23]
NEW: Several new mocked gui functions  
NEW: Added mock.gui.lua tests

## DefTest 2.0.0 [britzl released 2018-04-23]
CHANGE: Moved deftest.mock.lua to deftest.mock.mock.lua  
NEW: Added deftest.util.unload.lua  
NEW: Added deftest.mock.gui.lua

## DefTest 1.2.1 [britzl released 2017-10-27]
Updated and added more tests

## DefTest 1.2 [britzl released 2016-11-28]
Added mock/time.lua to mock time functions such as socket.gettime() os.date() and os.time()  


## DefTest 1.1 [britzl released 2016-11-28]
Moved mock_fs.lua to mock/fs.lua


## DefTest 1.0 [britzl released 2016-11-28]


